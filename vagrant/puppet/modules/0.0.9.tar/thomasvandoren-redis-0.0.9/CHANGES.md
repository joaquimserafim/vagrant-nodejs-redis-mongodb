redis module for puppet
=======================

0.0.9
-----
Use maestrodev/wget and puppetlabs/gcc to replace some common package dependencies. - @garethr

0.0.8
-----
Fix init script when redis_bind_address is not defined (the default).

0.0.7
-----
Add support for parameterized listening port and bind address.

0.0.6
-----
Add support for installing any available version.

0.0.5
-----
Add option to install 2.6.
Add spec tests.

0.0.4
-----
It's possible to configure a password to redis setup.

0.0.3
-----
Fix init script.

0.0.2
-----
Change the name to redis so that module name and class name are in sync.

0.0.1
-----
First release!
